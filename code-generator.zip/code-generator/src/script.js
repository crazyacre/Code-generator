document.getElementById('billingForm').addEventListener('submit', function(e) {
  e.preventDefault();

  // Ensure all required fields are filled
  const patientType = document.getElementById('patientType').value;
  const insuranceType = document.getElementById('insuranceType').value;
  const timeSpent = parseInt(document.getElementById('timeSpent').value) || 0;
  const smokingStatus = document.getElementById('smokingStatus').value;
  const patientAge = parseInt(document.getElementById('patientAge').value) || 0;
  const packYears = parseFloat(document.getElementById('packYears').value) || 0;
  const testsProcedures = document.getElementById('testsProcedures').checked;
  const cessationTime = parseInt(document.getElementById('cessationTime').value) || 0;

  // Show/hide conditional inputs
  const packYearsDiv = document.getElementById('packYearsDiv');
  const smokingCessationDiv = document.getElementById('smokingCessation');
  packYearsDiv.style.display = (smokingStatus === 'current' || smokingStatus === 'former15orless') ? 'block' : 'none';
  smokingCessationDiv.style.display = smokingStatus === 'current' ? 'block' : 'none';

  // Validate required fields
  if (!patientType || !insuranceType || !timeSpent || !smokingStatus || !patientAge) {
    document.getElementById('output').textContent = 'Please fill out all required fields.';
    document.getElementById('results').style.display = 'block';
    return;
  }

  let output = '';

  // E/M Billing Codes
  let baseCode = '';
  let prolongedCode = '';
  let prolongedUnits = 0;

  if (patientType === 'new') {
    if (timeSpent >= 15 && timeSpent <= 29) baseCode = '99202';
    else if (timeSpent >= 30 && timeSpent <= 44) baseCode = '99203';
    else if (timeSpent >= 45 && timeSpent <= 59) baseCode = '99204';
    else if (timeSpent >= 60) baseCode = '99205';
    
    if (insuranceType === 'medicare' && timeSpent >= 89) {
      prolongedUnits = Math.floor((timeSpent - 74) / 15);
      prolongedCode = `G2212 x ${prolongedUnits} unit(s)`;
    } else if (insuranceType === 'non-medicare' && timeSpent >= 75) {
      prolongedUnits = Math.floor((timeSpent - 74) / 15);
      prolongedCode = `99417 x ${prolongedUnits} unit(s)`;
    }
  } else if (patientType === 'established') {
    if (timeSpent >= 10 && timeSpent <= 19) baseCode = '99212';
    else if (timeSpent >= 20 && timeSpent <= 29) baseCode = '99213';
    else if (timeSpent >= 30 && timeSpent <= 39) baseCode = '99214';
    else if (timeSpent >= 40) baseCode = '99215';
    
    if (insuranceType === 'medicare' && timeSpent >= 69) {
      prolongedUnits = Math.floor((timeSpent - 54) / 15);
      prolongedCode = `G2212 x ${prolongedUnits} unit(s)`;
    } else if (insuranceType === 'non-medicare' && timeSpent >= 55) {
      prolongedUnits = Math.floor((timeSpent - 54) / 15);
      prolongedCode = `99417 x ${prolongedUnits} unit(s)`;
    }
  }

  output += `E/M Code: ${baseCode}${testsProcedures ? ' -25' : ''}`;
  if (prolongedCode) output += `\nProlonged Visit: ${prolongedCode}`;

  // LDCT Screening Eligibility
  const ldctEligible = (patientAge >= 50 && patientAge <= 80) && 
                      (smokingStatus === 'current' || smokingStatus === 'former15orless') && 
                      (packYears >= 20);
  output += `\nLDCT Eligibility: ${ldctEligible ? 'Eligible' : 'Not Eligible'}`;
  if (ldctEligible) {
    output += `\nLDCT Code: 71271${testsProcedures && !baseCode.includes('-25') ? ' -25' : ''}`;
  }

  // Smoking Cessation
  if (smokingStatus === 'current' && cessationTime > 0) {
    let cessationCode = cessationTime >= 3 && cessationTime <= 10 ? '99406' : cessationTime > 10 ? '99407' : '';
    if (cessationCode) {
      output += `\nSmoking Cessation: ${cessationCode}${testsProcedures && !baseCode.includes('-25') && !ldctEligible ? ' -25' : ''}`;
    }
  }

  // Display results
  document.getElementById('output').textContent = output;
  document.getElementById('results').style.display = 'block';
});